const app = {
    init: () => {
        console.log("app running");
    }
};

setTimeout(app.init, 1000);